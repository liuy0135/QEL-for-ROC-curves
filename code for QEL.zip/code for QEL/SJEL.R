

Gt <- function(z){
  0 * I(z<=-1) + 1* I(z>=1) +(15/16)*(z-(2/3)*z^3+(1/5)*z^5+(8/15))*I(abs(z)<1)
}


###########????ʹ????smoothed jackknife empirical likelihood method for ROC######
###here x and y are reverse to those of SEL and QEL
sjel.out <- function(x, y, t, theta){    #smoothed jackknife empirical likehood
  library(emplik)
  
  m <- length(x)
  n <- length(y)
  h=m^(-1/3)
  ##############Rmni begin
  ##i in c(1, m)   ???м???  outer??��????��??????BXA
  gnxj <- apply(outer(X=y, Y=x,  FUN = "<="), 2,mean)
  kgnxj <- Gt( (1 - t - gnxj)/h )
  
  Rmn <- 1 - mean(kgnxj)
  
  Rmni <- NULL
  for(i in 1:m){
    Rmni[i] <- 1 - mean(kgnxj[-i])
  }
  
  ## i in m+1, m+n
  for(i in (m+1):(m+n)){
    gnimxj <- apply(outer(X=y[-(i-m)], Y=x,  FUN = "<="), 2,mean)
    kgnimxj <- Gt( (1 - t - gnimxj) / h)
    Rmni[i] <- 1-mean( kgnimxj)
  }
  #############Rmni end
  vit <- (m + n) * Rmn - (m + n - 1) * Rmni
  
  myfun <- function(x,theta) {
    el.test(x, mu=theta)
  }
  
  tmp=el.test(vit,theta)
  tmp_bd=tryCatch(findUL(step = 0.01,MLE=theta, fun=myfun,x=vit), error=function(err) list(Low=0,Up=1))
  tmp_bd90=tryCatch(findUL(step = 0.01,MLE=theta, fun=myfun,x=vit,level = 2.705543), error=function(err) list(Low=0,Up=1))
  cp90=ifelse(tmp$Pval>0.1,1,0)
  cp95=ifelse(tmp$Pval>0.05,1,0)
  al95=tmp_bd$Up-tmp_bd$Low
  al90=tmp_bd90$Up-tmp_bd90$Low
  return(list(cp90=cp90,cp95=cp95,al90=al90,al95=al95))
}



sjel.bd <- function(x, y, t,thetat){    #smoothed jackknife empirical likehood
  
  m <- length(x)
  n <- length(y)
  h=m^(-1/3)
  ##############Rmni begin
  ##i in c(1, m)   ???м???  outer??��????��??????BXA
  gnxj <- apply(outer(X=y, Y=x,  FUN = "<="), 2,mean)
  kgnxj <- Gt( (1 - t - gnxj)/h )
  
  Rmn <- 1 - mean(kgnxj)
  
  Rmni <- NULL
  for(i in 1:m){
    Rmni[i] <- 1 - mean(kgnxj[-i])
  }
  
  ## i in m+1, m+n
  for(i in (m+1):(m+n)){
    gnimxj <- apply(outer(X=y[-(i-m)], Y=x,  FUN = "<="), 2,mean)
    kgnimxj <- Gt( (1 - t - gnimxj) / h)
    Rmni[i] <- 1-mean( kgnimxj)
  }
  #############Rmni end
  vit <- (m + n) * Rmn - (m + n - 1) * Rmni
  
  myfun <- function(x,theta) {
    el.test(x, mu=theta)
  }
  
  
  tmp_bd=tryCatch(findUL(step = 0.01,MLE=thetat, fun=myfun,x=vit), error=function(err) list(Low=0,Up=1))
  return(list(low=tmp_bd$Low,up=tmp_bd$Up))
}

###sjel.bd(x1, x2, t,thetat)
###sjel.out(y, x, t, theta)