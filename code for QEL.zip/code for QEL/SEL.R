library(BB)

Gh <- function(z){
  0 * I(z<=-1) + 1* I(z>=1) +(15/16)*(z-(2/3)*z^3+(1/5)*z^5+(8/15))*I(abs(z)<1)
}


Kt<-function(z){
  (15/16)*(1-z^2)^2*I(abs(z)<=1)   ##?˺???##
}


########??eta?Ľ?#####
w1<-function(z,x1,theta,h1){    #w1?Ĺ?ʽ
  Gh((z-x1)/h1)-(1-theta)
}

w2<-function(z,x2,t0,h2){   #w2?Ĺ?ʽ
  Gh((z-x2)/h2)-(1-t0)
}
######lambda1,lambda2??????#######


obj_f=function(par,x1,x2,t0,theta,h1,h2){
  lambda1=par[1]
  lambda2=par[2]
  eta=par[3]
  a1<-sum(w1(eta,x1,theta,h1)/(1+lambda1*w1(eta,x1,theta,h1)))
  a2=sum(w2(eta,x2,t0,h2)/(1+lambda2*w2(eta,x2,t0,h2)))
  ##
  w0.1<-function(beta,x1,h1){
    1/h1*Kt((beta-x1)/h1)
  }
  w0.2<-function(beta,x2,h2){
    1/h2*Kt((beta-x2)/h2)
  }
  part1=sum(lambda1*w0.1(eta,x1,h1)/(1+lambda1*w1(eta,x1,theta,h1)))
  part2=sum(lambda2*w0.2(eta,x2,h2)/(1+lambda2*w2(eta,x2,theta,h2)))
  a3=part1+part2
  aa=a1^2+a2^2+a3^2
  aa
}

sol_f=function(x1,x2,t0,theta,h1,h2){
  lo <- max(min(x1), min(x2))
  up <- min(max(x1), max(x2))
  eta.int<- quantile(x2, probs = 1- t0)
  if(eta.int < lo[1]){
    eta.int <- lo[1] + 0.01
  }else if(eta.int > up[1]){
    eta.int <- up[1] - 0.01
  }else{
    eta.int <- eta.int
  }
  #nlm(obj_f,c(0,0,eta.int),x1=x1,x2=x2,t0=t0,theta=theta,h1=h1,h2=h2)$estimate
  #BBoptim(c(0.1,0.1,eta.int),obj_f,x1=x1,x2=x2,t0=t0,theta=theta,h1=h1,h2=h2)
  optim(c(0,0,eta.int),obj_f,x1=x1,x2=x2,t0=t0,theta=theta,h1=h1,h2=h2, method = "L-BFGS-B")$par
}
#####-2llr(??????????Ȼ?Ⱥ???)#####
l.theta<-function(theta,t0,x1,x2,h1,h2){
  est=sol_f(x1,x2,t0,theta,h1,h2)
  lam1=est[1]
  lam2=est[2]
  eta=est[3]
  
  l.thetapart1<-sum(log(1+lam1*w1(eta,x1,theta,h1)))
  l.thetapart2<-sum(log(1+lam2*w2(eta,x2,t0,h2)))
  l.thetaout<-2*(l.thetapart1 + l.thetapart2)
  return(list(`-2LLR` = l.thetaout,lam1=lam1,lam2=lam2,eta=eta))
}


##### cannot work
sel_findul=function(theta,t,x,y,h1,h2){
  ff=function(theta,t,x,y,h1,h2,eta,lam1,lam2){
    l.thetapart1<-sum(log(1+lam1*w1(eta,y,theta,h1)))
    l.thetapart2<-sum(log(1+lam2*w2(eta,x,t,h2)))
    2*(l.thetapart1 + l.thetapart2)
  }
  
  tmp=l.theta(theta,t,y,x,h1,h2)
  if(tmp$`-2LLR`>qchisq(0.95,1)) {al95=al90=1}
  else{
    lam1=tmp$lam1;lam2=tmp$lam2;eta=tmp$eta
    ss=seq(-theta,1-theta,length.out=50)
    id_mid=which.min(abs(ss - theta))
    nn=NULL
    for (k in 1:50){
      nn[k]=ff(theta+ss[k],t,x,y,h1,h2,eta,lam1,lam2)
      #l.theta(theta+ss[k],t,y,x,h1,h2)
    }
    nn[is.na(nn)]=100
    
    n90=which(nn>2.705543)
    n95=which(nn>3.841459)
    bk90=max(c(1,which(n90<id_mid)))
    fd90=n90[min(c(which(n90>id_mid)))]
    fd90[is.na(fd90)]=1
    al90=ss[fd90]-ss[bk90]
    
    bk95=max(c(1,which(n95<id_mid)))
    fd95=n95[min(c(which(n95>id_mid)))]
    fd95[is.na(fd95)]=1
    al95=ss[fd95]-ss[bk95]
    
  }
  list(al90=al90,al95=al95)
  
}



sel.out= function(theta,t,x,y,h1,h2) {
  val=l.theta(theta,t,y,x,h1,h2)$`-2LLR`
  cp90=ifelse(val<qchisq(0.9,df=1),1,0)
  cp95=ifelse(val<qchisq(0.95,df=1),1,0)
  uplow= sel_findul(theta,t,x,y,h1,h2)
    #list(al90=1,al95=1)#
  #uplow= findul(step=0.01, fun=l.theta, MLE=theta, t=t, x1=y, x2=x,h1,h2)
  #findul2(step=0.01, fun=l.theta, MLE=theta, t=t, x1=y, x2=x,h1,h2)
  
  #al95=uplow$al95
  #al90=uplow$al90
  
  list(cp90=cp90,cp95=cp95,val=val)#,al90=al90,al95=al95,
}

#sel.out(theta,t,x,y,h0,h1)