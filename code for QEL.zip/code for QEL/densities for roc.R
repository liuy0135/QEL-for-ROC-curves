x=rexp(n0,1.8)F2
y=rnorm(n1,1,0.5)F1

xis=seq(-4,4,length.out=500)
yis=dnorm(xis,0,1)##F1##Case A in gong
#yis=dnorm(xis,0,1.5)##case A in ours
#yis=dnorm(xis,1,0.5)###
yis=dexp(xis,1)

#yyis=dnorm(xis,1,0.5)##Case A in gong
#yyis=dnorm(xis,1,0.5)##Case A in ours
yyis=dexp(xis,1.8)

plot(xis,yis,type="l",xlim = c(-4,4),ylim = c(0,max(c(yis,yyis))+0.05),xlab = "",ylab = "",main = "Case (A) in Gong et al. (2010)")
lines(xis,yyis,type="l",xlim = c(-4,4),lty=2,col=2)

legend("topright",legend=c("F1","F2"),col = c(1:2),lty=c(1:2))

z5=qnorm(0.95,1,0.5)
#z5=qexp(0.95,1.8)
abline(v=z5,lty=3,col=2)

xx=xis[xis>z5]

yy=yis[xis>z5]

polygon(c(xx,
          rev(xx)),
        c(yy,
          rev(rep(0,length(yy)))),
        col = "blue",density = 10, angle = 45)

gg=yyis[xis>z5]
polygon(c(xx,
          rev(xx)),
        c(gg,
          rev(rep(0,length(gg)))),
        col = "red",density = 20, angle = 135)


legend("topleft", legend=c("t","R(t)"), fill=c("red", "blue"),
       density=c(10, 20),angle =c(45,135), bty="n")

