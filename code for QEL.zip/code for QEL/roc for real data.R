getwd()
setwd("/Users/lym/Desktop/qel_sim/real data")
library(emplik)

Gt <- function(z){
  0 * I(z<=-1) + 1* I(z>=1) +(15/16)*(z-(2/3)*z^3+(1/5)*z^5+(8/15))*I(abs(z)<1)
}
fnone <- function(theta0,t0,x, y){
  n0 <- length(x)
  n1 <- length(y)
  h0=n0^(-1/3);h1=n1^(-1/3)
  ## parameter const
  lo <- max(min(x), min(y))
  up <- min(max(x), max(y))
  
  ###########object function
  fn <- function(beta){ ## beta <- c(eta, theta)
    
    Gn <- mean(Gt((beta - x) / h0))
    Fn <- mean(Gt((beta - y) / h1))
    
    part1 <- 2 * n1 * (  Fn * log( Fn / (1 - theta0) )   +  (1 - Fn)  * log( (1 - Fn) / theta0 ) ) #(2.11)
    part2 <- 2 * n0 * (  Gn * log( Gn / (1 - t0    ) )   +  (1 - Gn)  * log( (1 - Gn) / t0     ) ) #(2.11)
    a <- part1 + part2
    return(a)
  }
  
  
  
  
  eta.int <- quantile(x, probs = 1- t0)
  ######################################
  if(eta.int < lo[1]){
    eta.int <- lo[1] + 0.01
  }else if(eta.int > up[1]){
    eta.int <- up[1] - 0.01
  }else{
    eta.int <- eta.int
  }
  #############???Ż?????  ######
  ret <-optim(par=eta.int, fn=fn, lower=lo, upper=up,  method = "L-BFGS-B")
  #BB::BBoptim(par=eta.int, fn=fn, lower=lo, upper=up, control = list(maximize=F, trace=FALSE, maxit=1e4))
  bb <- ret$value  #fn??ֵ
  return(list(beta=ret$par, `-2LLR` = bb , Pval = 1 - pchisq(bb, df = 1)))
  
}

findul <- function(step = 0.01, initStep = 0, fun, MLE, level = 3.84146, ...)
{
  value <- 0
  step1 <- step
  
  Lbeta <- MLE - initStep
  while (value < level&&Lbeta>0.002) {
    Lbeta <- Lbeta - step1
    value <-  tryCatch(fun(Lbeta, ...)$"-2LLR", error=function(err) 0)
  }
  Lbeta0 <- Lbeta
  Lbeta1 <- Lbeta + step1
  tempfun <- function(beta){
    return( level - fun(beta, ...)$"-2LLR" )
  }
  if(Lbeta>0){
    temp1 <- tryCatch(uniroot(tempfun, lower=Lbeta0, upper=Lbeta1), error=function(err) list(root=(Lbeta0+Lbeta1)/2))
    Lbeta <- temp1$root
    value1 <- tryCatch(level - temp1$f.root, error=function(err) 0)}
  else{Lbeta=0}
  value <- 0
  Ubeta <- MLE + initStep
  while (value < level&&Ubeta<0.998) {
    Ubeta <- Ubeta + step
    value <- tryCatch(fun(Ubeta, ...)$"-2LLR", error=function(err) 1)
  }
  Ubeta0 <- Ubeta
  Ubeta1 <- Ubeta - step
  if(Ubeta<1){
    temp2 <- tryCatch(uniroot(tempfun, lower=Ubeta1, upper=Ubeta0), error=function(err) list(root=(Ubeta0+Ubeta1)/2))
    Ubeta <- temp2$root
    value <- tryCatch(level - temp2$f.root, error=function(err) 0)}
  else{Ubeta=1}
  return(list(low = Lbeta, up = Ubeta))
}
sjel.bd <- function(x, y, t,thetat){    #smoothed jackknife empirical likehood
  
  m <- length(x)
  n <- length(y)
  h=m^(-1/3)
  ##############Rmni begin
  ##i in c(1, m)   ???м???  outer??��????��??????BXA
  gnxj <- apply(outer(X=y, Y=x,  FUN = "<="), 2,mean)
  kgnxj <- Gt( (1 - t - gnxj)/h )
  
  Rmn <- 1 - mean(kgnxj)
  
  Rmni <- NULL
  for(i in 1:m){
    Rmni[i] <- 1 - mean(kgnxj[-i])
  }
  
  ## i in m+1, m+n
  for(i in (m+1):(m+n)){
    gnimxj <- apply(outer(X=y[-(i-m)], Y=x,  FUN = "<="), 2,mean)
    kgnimxj <- Gt( (1 - t - gnimxj) / h)
    Rmni[i] <- 1-mean( kgnimxj)
  }
  #############Rmni end
  vit <- (m + n) * Rmn - (m + n - 1) * Rmni
  
  myfun <- function(x,theta) {
    el.test(x, mu=theta)
  }
  
 
  tmp_bd=tryCatch(findUL(step = 0.01,MLE=thetat, fun=myfun,x=vit), error=function(err) list(Low=0,Up=1))
  return(list(low=tmp_bd$Low,up=tmp_bd$Up))
}


nams=c("ALB","CHE","ALP"," CHOT","ALT","CREA","AST","GGT","BIL","PROT")

data1<-read.table("/Users/lym/Desktop/qel_sim/real data/HepatitisCdata11 - 1.csv",header=T,sep = ",")
data0<-read.table("/Users/lym/Desktop/qel_sim/real data/HepatitisCdata11 - 0.csv",header=T,sep = ",")

for(id in 1:10){
x1 <- data0[,id]
x2 <- data1[,id]


ss=seq(0.05,0.5,0.025)
len=length(ss)

sjel_up=sjel_low=NULL
qel_up=qel_low=NULL
the=NULL
for (j in 1:len){
t=ss[j]
F1=ecdf(x1)
thetat=1-F1(quantile(x2,1-t))
the[j]=thetat
tmp1=sjel.bd(x1, x2, t,thetat)

sjel_up[j]=tmp1$up;sjel_low[j]=tmp1$low

tmp2=findul(step=0.01, fun=fnone, MLE=thetat, t0=t, x=x2, y=x1)

qel_up[j]=tmp2$up;qel_low[j]=tmp2$low

}

ou=which(sjel_up==1)



png(paste("idx",id,".png"), width = 600, height = 450)
plot(ss,sjel_up,ylim=c(0,1),type="p",lty=2,col=2,main =paste("Confidence interval bands of ",nams[id]),xlab= "FPR",ylab = "ROC curve value",pch=2 )
points(ss,sjel_low,lty=2,col=2,pch=2)

lines(ss[-ou],sjel_low[-ou],lty=2,col=2)
lines(ss[-ou],sjel_up[-ou],lty=2,col=2)

lines(ss,the,type="b")

lines(ss,qel_up,type="b",col=3,lty=3,pch=3)
lines(ss,qel_low,type="b",col=3,lty=3,pch=3)

legend("topleft",legend = c("EROC","SJEL","QEL"),lty=c(1:3),col = c(1:3),pch = c(1:3))



dev.off()
}
                                                                                       
                                                                                       