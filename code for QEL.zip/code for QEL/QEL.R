Gt <- function(z){
  0 * I(z<=-1) + 1* I(z>=1) +(15/16)*(z-(2/3)*z^3+(1/5)*z^5+(8/15))*I(abs(z)<1)
}
####proposed method
fnone <- function(theta0,t0,x, y){
  n0 <- length(x)
  n1 <- length(y)
  h0=n0^(-1/3);h1=n1^(-1/3)
  ## parameter const
  lo <- max(min(x), min(y))
  up <- min(max(x), max(y))
  
  ###########object function
  fn <- function(beta){ ## beta <- c(eta, theta)
    
    Gn <- mean(Gt((beta - x) / h0))
    Fn <- mean(Gt((beta - y) / h1))
    
    part1 <- 2 * n1 * (  Fn * log( Fn / (1 - theta0) )   +  (1 - Fn)  * log( (1 - Fn) / theta0 ) ) #(2.11)
    part2 <- 2 * n0 * (  Gn * log( Gn / (1 - t0    ) )   +  (1 - Gn)  * log( (1 - Gn) / t0     ) ) #(2.11)
    a <- part1 + part2
    return(a)
  }
  

  
  
  eta.int <- quantile(x, probs = 1- t0)
  ######################################
  if(eta.int < lo[1]){
    eta.int <- lo[1] + 0.01
  }else if(eta.int > up[1]){
    eta.int <- up[1] - 0.01
  }else{
    eta.int <- eta.int
  }
  #############???Ż?????  ######
  ret <-optim(par=eta.int, fn=fn, lower=lo, upper=up,  method = "L-BFGS-B")
  #BB::BBoptim(par=eta.int, fn=fn, lower=lo, upper=up, control = list(maximize=F, trace=FALSE, maxit=1e4))
  bb <- ret$value  #fn??ֵ
  return(list(beta=ret$par, `-2LLR` = bb , Pval = 1 - pchisq(bb, df = 1)))
  
}

findul <- function(step = 0.01, initStep = 0, fun, MLE, level = 3.84146, ...)
{
  value <- 0
  step1 <- step
  
  Lbeta <- MLE - initStep
  while (value < level&&Lbeta>0.002) {
    Lbeta <- Lbeta - step1
    value <-  tryCatch(fun(Lbeta, ...)$"-2LLR", error=function(err) 0)
  }
  Lbeta0 <- Lbeta
  Lbeta1 <- Lbeta + step1
  tempfun <- function(beta){
    return( level - fun(beta, ...)$"-2LLR" )
  }
  if(Lbeta>0){
    temp1 <- tryCatch(uniroot(tempfun, lower=Lbeta0, upper=Lbeta1), error=function(err) list(root=(Lbeta0+Lbeta1)/2))
    Lbeta <- temp1$root
    value1 <- tryCatch(level - temp1$f.root, error=function(err) 0)}
  else{Lbeta=0}
  value <- 0
  Ubeta <- MLE + initStep
  while (value < level&&Ubeta<0.998) {
    Ubeta <- Ubeta + step
    value <- tryCatch(fun(Ubeta, ...)$"-2LLR", error=function(err) 1)
  }
  Ubeta0 <- Ubeta
  Ubeta1 <- Ubeta - step
  if(Ubeta<1){
    temp2 <- tryCatch(uniroot(tempfun, lower=Ubeta1, upper=Ubeta0), error=function(err) list(root=(Ubeta0+Ubeta1)/2))
    Ubeta <- temp2$root
    value <- tryCatch(level - temp2$f.root, error=function(err) 0)}
  else{Ubeta=1}
  return(list(Low = Lbeta, Up = Ubeta))
}
qel.out=function(theta0,t0,x, y){
  val=fnone(theta0,t0,x, y)$`-2LLR`
  cp90=ifelse(val<qchisq(0.9,df=1),1,0)
  cp95=ifelse(val<qchisq(0.95,df=1),1,0)
  uplow= findul(step=0.01, fun=fnone, MLE=theta, t0=t, x=x, y=y)
  uplow90= findul(step=0.01, fun=fnone, MLE=theta, t0=t, x=x, y=y,level = 2.705543)
  al95=uplow$Up-uplow$Low
  al90=uplow90$Up-uplow90$Low
  list(cp90=cp90,cp95=cp95,al90=al90,al95=al95)
  
}

###qel.out(theta,t,x, y)
